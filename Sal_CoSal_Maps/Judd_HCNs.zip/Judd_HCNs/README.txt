The saliency maps and the evaluation measures of our HCN method on the dataset JuddDB, if you use this result please cite:

Jing Lou, Fenglei Xu, Qingyuan Xia, Wankou Yang, Mingwu Ren, "Hierarchical Co-salient Object Detection via Color Names," in Proceedings of the Asian Conference on Pattern Recognition (ACPR), pp. 718-724, 2017. (Spotlight)

Project webpage: http://www.loujing.com/hcn-co-sod/