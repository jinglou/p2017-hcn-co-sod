%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% Jing Lou, Fenglei Xu, Qingyuan Xia, Wankou Yang, Mingwu Ren, "Hierarchical Co-salient Object Detection via Color Names,"
% in Proceedings of the Asian Conference on Pattern Recognition (ACPR), pp. 1-7, 2017. (Spotlight)
% 
% Project page: http://www.loujing.com/hcn-co-sod/
%
% Copyright (C) 2017 Jing Lou (¥��)
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% PLOTPRF plots Precision-Recall curve, F-measure curve, and Precision-Recall bar of the proposed HCNco model.
% 	1. The variable PRF includes 3 columns:
%       Column 1:	Precision
% 		Column 2:	Recall
% 		Column 3:	F-measure
%   2. The variable PRF includes 257 rows:
%       Rows 1~256:	fixed thresholding ($T_f \in [0,255]$)
%       Row  257:	adaptive thresholding ($T_a$)

clc; clear; close all;

load('ImagePair_HCNco_PRF.mat');

%% Precision-Recall curve
figure;
plot(PRF(1,2), PRF(1,1), 'Marker','.', 'MarkerSize',25, 'Color', [1 0 0]);	% <--Notice!
hold on;
plot(PRF(2:256,2), PRF(2:256,1), 'Color',[1 0 0], 'LineWidth',4);
axis([0 1 0 1]);
set(gca, 'XTick',0:0.1:1);
set(gca, 'YTick',0:0.1:1);
set(gca, 'XTickLabel',{'0', '', '0.2', '', '0.4', '', '0.6', '', '0.8', '', '1'});
set(gca, 'YTickLabel',{'0', '', '0.2', '', '0.4', '', '0.6', '', '0.8', '', '1'});
grid on;
box off;
xlabel('Recall');
ylabel('Precision');
title('Precision-Recall curve (HCNco)');

%% F-measure curve
figure;
plot(0, PRF(1,3),  'Marker','.', 'MarkerSize',25, 'Color', [1 0 0]);		% <--Notice!
hold on;
plot(1:255, PRF(2:256,3), 'Color',[1 0 0], 'LineWidth',4);
axis([0 255 0 1]);
set(gca, 'XTick',0:50:255);
set(gca, 'YTick',0:0.1:1);
set(gca, 'YTickLabel',{'0', '', '0.2', '', '0.4', '', '0.6', '', '0.8', '', '1'});
grid on;
box off;
xlabel('Threshold');
ylabel('F-measure');
title('F-measure curve (HCNco)');

%% Precision-Recall bar
Color = [
	0.2157    0.4941    0.7216;
	0.8941    0.1020    0.1098;
	0.3020    0.6863    0.2902;
];
figure;
Bar(1,1:3) = [0 0 0];		% NO USE
Bar(2,1:3) = PRF(257,1:3);	% HCNs
b = bar(Bar);
for k = 1:3					% introduced after R2014b
	b(k).FaceColor = Color(k,:);
	b(k).EdgeColor = Color(k,:);
end
axis([1.25 2.5 0 1]);
legend('Precision','Recall','F-measure', 'Location','SouthWest');
set(gca, 'XTickLabel',{'', 'HCNco'});
set(gca, 'YTick', 0:0.1:1);
set(gca, 'YTickLabel', {'0', '', '0.2', '', '0.4', '', '0.6', '', '0.8', '', '1'});
set(gca, 'XGrid','off','YGrid','on');
box off;
title('Precision-Recall bar (HCNco)');




