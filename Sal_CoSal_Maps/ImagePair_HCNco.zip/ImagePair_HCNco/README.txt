The co-saliency maps and evaluation measures of the proposed HCNco model on the Image Pair data set. If you use this result, please cite:

Jing Lou, Fenglei Xu, Qingyuan Xia, Wankou Yang, Mingwu Ren, "Hierarchical Co-salient Object Detection via Color Names," in Proceedings of the Asian Conference on Pattern Recognition (ACPR), pp. 718-724, 2017. (Spotlight)

Project page: http://www.loujing.com/hcn-co-sod/